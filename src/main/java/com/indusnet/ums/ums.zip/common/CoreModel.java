package com.indusnet.ums.common;

public class CoreModel {

}
