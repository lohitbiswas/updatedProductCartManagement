package com.indusnet.ums.exception;

public class CustomFoundException extends RuntimeException{
    public CustomFoundException(String message) {
        super(message);
    }
}