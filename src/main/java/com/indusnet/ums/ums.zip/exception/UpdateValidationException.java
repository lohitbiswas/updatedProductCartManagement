package com.indusnet.ums.exception;


public class UpdateValidationException extends RuntimeException{
    public UpdateValidationException(String message) {
        super(message);
    }
}